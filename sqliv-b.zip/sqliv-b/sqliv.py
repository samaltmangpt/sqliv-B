import argparse
from src.scanner import scan
from src.crawler import AsyncCrawler
from lib.bing import Bing
from lib.yahoo import Yahoo

def main():
    parser = argparse.ArgumentParser(description="SQLiv-M: Massive SQL Injection Vulnerability Scanner")
    parser.add_argument('-d', '--dorkfile', help='File with dorks, one per line')
    parser.add_argument('--depth', type=int, default=1, help='Crawler max depth')
    args = parser.parse_args()
    
    if args.dorkfile:
        with open(args.dorkfile, 'r') as f:
            dorks = [line.strip() for line in f if line.strip()]
        
        results_file = open("results.txt", "w", encoding="utf-8")
        for dork in dorks:
            print(f"[*] Searching for dork: {dork}")
            search_results = []
            search_results += Bing().search(dork, stop=20)
            search_results += Yahoo().search(dork, pages=2)
            print(f"[*] Found {len(search_results)} URLs for dork: {dork}")
            for url in search_results:
                crawler = AsyncCrawler(max_depth=args.depth)
                urls_to_scan = crawler.run(url)
                for target_url in urls_to_scan:
                    result = scan([target_url])
                    for vuln_url, db in result:
                        print(f"[+] Vulnerable: {vuln_url} (db: {db})")
                        results_file.write(f"{vuln_url}\n")
                        results_file.flush()
        results_file.close()

if __name__ == "__main__":
    main()