import re
import requests
from urllib.parse import urlencode

class Bing:
    def __init__(self):
        self.bing_search = "https://www.bing.com/search?{}"
        self.regex = re.compile(r'<h2><a href="(http[s]?://[^"]+)"')

    def search(self, query, stop=100):
        links = []
        for start in range(1, stop+1, 10):
            params = urlencode({'q': query, 'first': start})
            url = self.bing_search.format(params)
            resp = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
            if resp.status_code != 200:
                break
            result = resp.text
            found_links = self.regex.findall(result)
            for l in found_links:
                if l not in links:
                    links.append(l)
        return links