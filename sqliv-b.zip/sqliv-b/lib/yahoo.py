import requests
from bs4 import BeautifulSoup

class Yahoo:
    def __init__(self):
        self.search_url = "https://search.yahoo.com/search?p={}"

    def search(self, query, pages=1):
        links = []
        for page in range(pages):
            url = self.search_url.format(requests.utils.quote(query))
            resp = requests.get(url, headers={"User-Agent": "Mozilla/5.0"})
            soup = BeautifulSoup(resp.text, "html.parser")
            for a in soup.select('a.ac-algo'):
                href = a.get("href")
                if href and href not in links:
                    links.append(href)
        return links