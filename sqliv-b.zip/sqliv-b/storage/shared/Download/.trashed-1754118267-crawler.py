import re
from urllib.parse import urlparse, urljoin
import requests
from bs4 import BeautifulSoup
from collections import deque

class Crawler:
    def __init__(self):
        self.links = []
        self.visited = set()
        self.max_depth = 1

    def crawl(self, url, depth=1):
        """Start crawling from the given url up to a certain depth."""
        self.max_depth = depth
        parsedurl = urlparse(url)
        domain = parsedurl.scheme + "://" + parsedurl.netloc

        self.links = []
        self.visited = set()
        self._bfs(domain)
        return self.links

    def _bfs(self, start_url):
        """Breadth-first crawl up to max_depth."""
        queue = deque()
        queue.append((start_url, 0))
        self.visited.add(start_url)

        while queue:
            current_url, cur_depth = queue.popleft()
            if cur_depth > self.max_depth:
                continue
            try:
                resp = requests.get(current_url, timeout=5)
                resp.raise_for_status()
                html = resp.text
            except Exception as e:
                continue

            soup = BeautifulSoup(html, "html.parser")
            # Extract links
            for a_tag in soup.find_all("a", href=True):
                link = urljoin(current_url, a_tag["href"])
                parsed_link = urlparse(link)
                # Stay within the same domain only
                if parsed_link.netloc != urlparse(start_url).netloc:
                    continue
                # Normalize link (remove fragments, etc)
                link = parsed_link.scheme + "://" + parsed_link.netloc + parsed_link.path
                if link not in self.visited:
                    self.visited.add(link)
                    # Add to crawl queue if depth allows
                    if cur_depth + 1 <= self.max_depth:
                        queue.append((link, cur_depth + 1))
                # SQLi-prone links
                if re.search(r'(.*?)(.php\?|.asp\?|.apsx\?|.jsp\?)(.*?)=(.*?)', link):
                    if link not in self.links:
                        self.links.append(link)