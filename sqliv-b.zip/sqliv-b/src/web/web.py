import requests
from .useragents import get

def gethtml(url, lastURL=False):
    """return HTML of the given url"""
    if not (url.startswith("http://") or url.startswith("https://")):
        url = "http://" + url
    headers = get()
    html = None
    try:
        reply = requests.get(url, headers=headers, timeout=10)
        html = reply.text
    except Exception:
        pass
    if html:
        if lastURL:
            return (html, reply.url)
        else:
            return html
    return False