# sqliv-M

## Web Crawler Modernization

> **Note:**  
> As of July 2025, the legacy `nyawc` web crawler has been **fully removed**.  
> sqliv-M now uses a modern, asynchronous, CIA/NSA-grade crawler built with Python 3’s `asyncio` and `aiohttp`, which is faster, more robust, and more scalable for web security research.
>
> - **Old:** `nyawc` (synchronous, legacy)
> - **Now:** `AsyncCrawler` (asynchronous, robust, modern)
>
> No additional installation of `nyawc` is needed. All crawling leverages native Python 3 concurrency.
