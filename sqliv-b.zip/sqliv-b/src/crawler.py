import asyncio
import aiohttp
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from collections import deque

class AsyncCrawler:
    """
    High-assurance, concurrency-safe web crawler for security research.
    """
    def __init__(self, max_depth=2, max_tasks=20, user_agents=None):
        self.max_depth = max_depth
        self.max_tasks = max_tasks
        self.visited = set()
        self.found_urls = set()
        self.user_agents = user_agents or [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.1 Safari/605.1.15",
            "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:110.0) Gecko/20100101 Firefox/110.0"
        ]
        self._session = None

    async def fetch(self, url, session, headers):
        try:
            async with session.get(url, headers=headers, timeout=10) as response:
                if response.status == 200 and 'text/html' in response.headers.get("Content-Type", ""):
                    return await response.text()
        except Exception:
            return None
        return None

    async def extract_links(self, url, html):
        soup = BeautifulSoup(html, "html.parser")
        links = set()
        for tag in soup.find_all("a", href=True):
            href = tag['href']
            abs_url = urljoin(url, href)
            abs_url = abs_url.split('#')[0]
            if abs_url.startswith('http'):
                links.add(abs_url)
        return links

    async def crawl(self, start_url):
        queue = deque()
        queue.append((start_url, 0))
        self.visited.add(start_url)
        connector = aiohttp.TCPConnector(ssl=False)
        async with aiohttp.ClientSession(connector=connector) as session:
            self._session = session
            while queue:
                tasks = []
                while queue and len(tasks) < self.max_tasks:
                    url, depth = queue.popleft()
                    tasks.append(self._crawl_single(url, depth, queue))
                if tasks:
                    await asyncio.gather(*tasks)

    async def _crawl_single(self, url, depth, queue):
        headers = {"User-Agent": self.user_agents[hash(url) % len(self.user_agents)]}
        html = await self.fetch(url, self._session, headers)
        if html is None:
            return
        self.found_urls.add(url)
        if depth < self.max_depth:
            links = await self.extract_links(url, html)
            for link in links:
                if link not in self.visited:
                    self.visited.add(link)
                    queue.append((link, depth + 1))

    def run(self, url):
        asyncio.run(self.crawl(url))
        return list(self.found_urls)