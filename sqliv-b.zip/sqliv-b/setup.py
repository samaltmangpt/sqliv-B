import argparse
import os
import stat
from sys import platform
from shutil import copy2, rmtree
from distutils.dir_util import copy_tree
import subprocess

__author__ = "Ghost"
__email__ = "official.ghost@tuta.io"
__license__ = "GPL"
__version__ = "3.0"

FILE_PATH_LINUX = "/usr/share/sqliv"
EXEC_PATH_LINUX = "/usr/bin/sqliv"

FILE_PATH_MAC = "/usr/local/bin"
EXEC_PATH_MAC = "/usr/local/bin"

def metadata():
    print("SQLiv (3.0) by {}".format(__author__))
    print("Massive SQL injection vulnerability scanner")

def dependencies():
    """install script dependencies with pip"""
    try:
        with open("requirements.txt", "r") as requirements:
            dependencies = requirements.read().splitlines()
    except IOError:
        print("requirements.txt not found, please redownload or do pull request again")
        exit(1)
    for lib in dependencies:
        subprocess.run(["pip3", "install", lib])

def install(file_path, exec_path):
    """full installation of SQLiv to the system"""
    os.makedirs(file_path, exist_ok=True)
    copy2("sqliv.py", file_path)
    copy2("requirements.txt", file_path)
    copy2("LICENSE", file_path)
    copy2("README.md", file_path)
    copy_tree("src", os.path.join(file_path, "src"))
    copy_tree("lib", os.path.join(file_path, "lib"))
    dependencies()
    with open(exec_path, 'w') as installer:
        installer.write('#!/bin/bash\n')
        installer.write('\n')
        installer.write('python3 {}/sqliv.py "$@"\n'.format(file_path))
    os.chmod(exec_path, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

def uninstall(file_path, exec_path):
    """uninstall sqliv from the system"""
    if os.path.exists(file_path):
        rmtree(file_path)
        print("Removed " + file_path)
    if os.path.isfile(exec_path):
        os.remove(exec_path)
        print("Removed " + exec_path)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-i", "--install", help="install sqliv in the system", action='store_true')
    parser.add_argument("-r", "--reinstall", help="remove old files and reinstall to the system", action="store_true")
    parser.add_argument("-u", "--uninstall", help="uninstall sqliv from the system", action="store_true")
    args = parser.parse_args()

    if platform == "linux" or platform == "linux2":
        if os.getuid() != 0:
            print("linux system requires root access for the installation")
            exit(1)
        FILE_PATH = FILE_PATH_LINUX
        EXEC_PATH = EXEC_PATH_LINUX
    elif platform == "darwin":
        FILE_PATH = FILE_PATH_MAC
        EXEC_PATH = EXEC_PATH_MAC
    else:
        print("Windows platform is not supported for installation")
        exit(1)
    if args.install or args.reinstall:
        if args.reinstall:
            uninstall(FILE_PATH, EXEC_PATH)
        install(FILE_PATH, EXEC_PATH)
    elif args.uninstall:
        uninstall(FILE_PATH, EXEC_PATH)