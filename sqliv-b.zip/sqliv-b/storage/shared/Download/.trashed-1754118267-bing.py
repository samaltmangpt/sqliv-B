#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author : Black Viking (Modernized)
Version: 0.0.4

Python 3 Bing searcher using requests & BeautifulSoup,
now decodes Bing redirect URLs to get the real destination.
"""

import time
import requests
from bs4 import BeautifulSoup
from urllib.parse import quote_plus, urlparse, parse_qs, unquote
import base64


class Bing:

    def __init__(self):
        self.base_url = "https://www.bing.com/search?q={query}&first={start}"
        self.headers = {
            'User-Agent': ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                           'AppleWebKit/537.36 (KHTML, like Gecko) '
                           'Chrome/114.0.0.0 Safari/537.36'),
            'Accept-Language':
            'en-US,en;q=0.9',
            'Connection':
            'close'
        }

    def _extract_real_url(self, bing_url):
        """
        If the URL is a Bing redirect (/ck/a), extract the real destination from the 'u' parameter.
        Decodes base64-encoded 'u' values, removing 'a1' prefix if present.
        """
        if bing_url.startswith("https://www.bing.com/ck/a"):
            parsed = urlparse(bing_url)
            params = parse_qs(parsed.query)
            if 'u' in params:
                u_val = params['u'][0]
                decoded = unquote(u_val)
                # Remove 'a1' prefix if present
                if decoded.startswith("a1"):
                    decoded = decoded[2:]
                # Try to decode base64 (Bing often uses it)
                try:
                    # Add padding if needed
                    missing_padding = len(decoded) % 4
                    if missing_padding:
                        decoded += '=' * (4 - missing_padding)
                    decoded = base64.b64decode(decoded).decode("utf-8")
                except Exception:
                    pass
                return decoded
        return bing_url

    def search(self, query, stop=50, pause=2.0):
        """
        Search Bing for a query and yield result URLs.
        :param query: Query string.
        :param stop: Max number of results to retrieve.
        :param pause: Seconds to pause between requests.
        :return: list of URLs
        """
        links = []
        start = 1
        fetched = 0

        print(f"[Bing] Searching for: {query}")
        while fetched < stop:
            url = self.base_url.format(query=quote_plus(query), start=start)
            try:
                r = requests.get(url, headers=self.headers, timeout=10)
                time.sleep(pause)
            except Exception as e:
                print(f"[Bing] Request failed: {e}")
                break

            soup = BeautifulSoup(r.text, "html.parser")
            results = soup.find_all('li', class_='b_algo')
            if not results:
                print(f"[Bing] No results found at start={start}.")
                break

            new_links = 0
            for res in results:
                a_tag = res.find('a', href=True)
                if a_tag:
                    link = a_tag['href']
                    real_link = self._extract_real_url(link)
                    if real_link not in links:
                        links.append(real_link)
                        new_links += 1
                        fetched += 1
                        print(real_link)
                        if fetched >= stop:
                            break

            if new_links == 0:
                print("[Bing] No new links found, ending search.")
                break

            start += 10

        return links


if __name__ == "__main__":
    bing = Bing()
    query = "faqanswer.php?faqid="
    urls = bing.search(query, stop=10)
    print("Found URLs:")
    for url in urls:
        print(url)
