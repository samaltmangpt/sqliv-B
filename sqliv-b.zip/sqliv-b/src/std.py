# Minimal version for output
import time

def stdout(message, end="\n"):
    print("[MSG] [{}] {}".format(time.strftime("%H:%M:%S"), message), end=end)

def stderr(message, end="\n"):
    print("[ERR] [{}] {}".format(time.strftime("%H:%M:%S"), message), end=end)

def showsign(message):
    print(message)