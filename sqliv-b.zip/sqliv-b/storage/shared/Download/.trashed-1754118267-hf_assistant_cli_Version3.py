import argparse
import json
from pathlib import Path
from transformers import AutoModelForCausalLM, AutoTokenizer

ASSISTANTS_FILE = Path.home() / ".hf_assistants.json"

def load_assistants():
    if ASSISTANTS_FILE.exists():
        with open(ASSISTANTS_FILE, "r") as f:
            return json.load(f)
    return {}

def save_assistants(assistants):
    with open(ASSISTANTS_FILE, "w") as f:
        json.dump(assistants, f, indent=2)

def list_assistants():
    assistants = load_assistants()
    if not assistants:
        print("No assistants created yet.")
        return
    print("Available assistants:")
    for name, config in assistants.items():
        print(f"- {name} (model: {config['model']})")
        print(f"  System: {config.get('system','')[:96]}{'...' if len(config.get('system',''))>96 else ''}")

def create_assistant(args):
    assistants = load_assistants()
    if args.name in assistants:
        print(f"Assistant '{args.name}' already exists.")
        return
    system = args.system
    if not system:
        system = input("Enter system instruction (leave blank for default): ").strip()
    if not system:
        system = "You are a helpful AI assistant."
    assistants[args.name] = {
        "model": args.model,
        "description": args.description or "",
        "system": system
    }
    save_assistants(assistants)
    print(f"Assistant '{args.name}' created with model '{args.model}' and system instruction.")

def chat_with_assistant(args):
    assistants = load_assistants()
    if args.name not in assistants:
        print(f"Assistant '{args.name}' not found.")
        return
    config = assistants[args.name]
    model_id = config["model"]
    system_message = config.get("system", "You are a helpful AI assistant.")

    print(f"Loading model '{model_id}'... (this may take a while on first use)")
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForCausalLM.from_pretrained(model_id)
    chat_template = getattr(tokenizer, "chat_template", None)

    print(f"\nChatting with assistant '{args.name}' (model: {model_id})")
    print("Type 'exit' or Ctrl+C to quit.\n")

    history = [{"role": "system", "content": system_message}]

    while True:
        try:
            user_input = input("You: ")
        except (EOFError, KeyboardInterrupt):
            print("\nExiting chat.")
            break
        if user_input.lower() in ["exit", "quit"]:
            print("Exiting chat.")
            break

        history.append({"role": "user", "content": user_input})

        if chat_template:
            prompt = tokenizer.apply_chat_template(history, tokenize=False, add_generation_prompt=True)
        else:
            # Fallback: system + chat history, format like Hugging Face chat
            prompt = system_message + "\n"
            for msg in history[1:]:
                prompt += f"{msg['role'].capitalize()}: {msg['content']}\n"
            prompt += "Assistant:"

        input_ids = tokenizer(prompt, return_tensors="pt").input_ids
        output = model.generate(input_ids, max_new_tokens=512, pad_token_id=tokenizer.eos_token_id)
        response = tokenizer.decode(output[0][input_ids.shape[-1]:], skip_special_tokens=True)
        print(f"{args.name}: {response}")
        history.append({"role": "assistant", "content": response})

def main():
    parser = argparse.ArgumentParser(
        description="Terminal CLI for managing and chatting with HuggingFace-style assistants (with system instructions)."
    )
    subparsers = parser.add_subparsers(dest="command")

    create_parser = subparsers.add_parser("create", help="Create a new assistant.")
    create_parser.add_argument("--name", required=True, help="Assistant name.")
    create_parser.add_argument("--model", required=True, help="HuggingFace model id (e.g. meta-llama/Llama-2-7b-chat-hf).")
    create_parser.add_argument("--description", help="Short description for the assistant.")
    create_parser.add_argument("--system", help="System instruction for the assistant.")

    subparsers.add_parser("list", help="List created assistants.")

    chat_parser = subparsers.add_parser("chat", help="Chat with an assistant.")
    chat_parser.add_argument("--name", required=True, help="Assistant name to chat with.")

    args = parser.parse_args()

    if args.command == "create":
        create_assistant(args)
    elif args.command == "list":
        list_assistants()
    elif args.command == "chat":
        chat_with_assistant(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()