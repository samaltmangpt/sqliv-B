import argparse
import json
from pathlib import Path
from transformers import AutoModelForCausalLM, AutoTokenizer

ASSISTANTS_FILE = Path.home() / ".hf_assistants.json"

def load_assistants():
    if ASSISTANTS_FILE.exists():
        with open(ASSISTANTS_FILE, "r") as f:
            return json.load(f)
    return {}

def save_assistants(assistants):
    with open(ASSISTANTS_FILE, "w") as f:
        json.dump(assistants, f, indent=2)

def list_assistants():
    assistants = load_assistants()
    if not assistants:
        print("No assistants created yet.")
        return
    print("Available assistants:")
    for name, config in assistants.items():
        print(f"- {name} (model: {config['model']})")
        print(f"  System: {config.get('system','')[:96]}{'...' if len(config.get('system',''))>96 else ''}")

def create_assistant_interactive():
    assistants = load_assistants()
    name = input("Assistant name: ").strip()
    if not name:
        print("Assistant name is required.")
        return
    if name in assistants:
        print(f"Assistant '{name}' already exists.")
        return
    model = input("HuggingFace model id (e.g. meta-llama/Llama-2-7b-chat-hf): ").strip()
    if not model:
        print("Model id is required.")
        return
    description = input("Short description (optional): ").strip()
    system = input("System instructions (leave blank for default): ").strip()
    if not system:
        system = "You are a helpful AI assistant."
    assistants[name] = {
        "model": model,
        "description": description,
        "system": system
    }
    save_assistants(assistants)
    print(f"Assistant '{name}' created with model '{model}'.")

def chat_with_assistant(name):
    assistants = load_assistants()
    if name not in assistants:
        print(f"Assistant '{name}' not found.")
        return
    config = assistants[name]
    model_id = config["model"]
    system_message = config.get("system", "You are a helpful AI assistant.")

    print(f"Loading model '{model_id}'... (this may take a while on first use)")
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForCausalLM.from_pretrained(model_id)
    chat_template = getattr(tokenizer, "chat_template", None)

    print(f"\nChatting with assistant '{name}' (model: {model_id})")
    print("Type 'exit' or Ctrl+C to quit.\n")

    history = [{"role": "system", "content": system_message}]

    while True:
        try:
            user_input = input("You: ")
        except (EOFError, KeyboardInterrupt):
            print("\nExiting chat.")
            break
        if user_input.lower() in ["exit", "quit"]:
            print("Exiting chat.")
            break

        history.append({"role": "user", "content": user_input})

        if chat_template:
            prompt = tokenizer.apply_chat_template(history, tokenize=False, add_generation_prompt=True)
        else:
            # Fallback: system + chat history, format like Hugging Face chat
            prompt = system_message + "\n"
            for msg in history[1:]:
                prompt += f"{msg['role'].capitalize()}: {msg['content']}\n"
            prompt += "Assistant:"

        input_ids = tokenizer(prompt, return_tensors="pt").input_ids
        output = model.generate(input_ids, max_new_tokens=512, pad_token_id=tokenizer.eos_token_id)
        response = tokenizer.decode(output[0][input_ids.shape[-1]:], skip_special_tokens=True)
        print(f"{name}: {response}")
        history.append({"role": "assistant", "content": response})

def main_menu():
    while True:
        print("\nHuggingFace Assistant CLI")
        print("1. List assistants")
        print("2. Create assistant")
        print("3. Enter assistant name to use")
        print("4. Quit")
        choice = input("Select an option (1-4): ").strip()
        if choice == "1":
            list_assistants()
        elif choice == "2":
            create_assistant_interactive()
        elif choice == "3":
            assistants = load_assistants()
            name = input("Assistant name to use: ").strip()
            if not name:
                print("Please enter an assistant name.")
                continue
            if name not in assistants:
                print(f"Assistant '{name}' does not exist.")
                continue
            chat_with_assistant(name)
        elif choice == "4":
            print("Goodbye!")
            break
        else:
            print("Invalid selection.")

def main():
    parser = argparse.ArgumentParser(description="HuggingFace Assistant CLI")
    parser.add_argument("--menu", action="store_true", help="Start in interactive menu mode (default)")
    args = parser.parse_args()
    main_menu()

if __name__ == "__main__":
    main()